//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MfcToolbar.rc
//
#define IDS_PROJNAME                    100
#define IDR_TOOLBAR                     200
#define ID_BUTTON_FIRST                 32768
#define ID_BUTTON_SECOND                32769

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32770
#define _APS_NEXT_CONTROL_VALUE         200
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
