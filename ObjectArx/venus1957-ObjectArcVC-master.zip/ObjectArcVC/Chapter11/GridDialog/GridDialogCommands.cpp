//
// ObjectARX defined commands

#include "StdAfx.h"
#include "StdArx.h"
#include "GridDlg.h"

// This is command 'SHOWGRIDDLG'
void ZffChap11ShowGridDlg()
{
	CAcModuleResourceOverride myResource;
	CGridDlg dlg;
	dlg.DoModal();
}

