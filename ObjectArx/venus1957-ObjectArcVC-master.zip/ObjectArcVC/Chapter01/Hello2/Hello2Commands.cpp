//
// ObjectARX defined commands

#include "StdAfx.h"
#include "StdArx.h"

// This is command 'HELLO'
void ZffBASICHello()
{
	acutPrintf(TEXT("\nHello,World!"));
}

