//
// StdArx.h : include file for ObjectARX/DBX include files
// this file is only included once by your stdafx.h

#if !defined(AFX_STDARX_H__5EE73F8F_E439_4284_B7F6_2CF95E38C116__INCLUDED_)
#define AFX_STDARX_H__5EE73F8F_E439_4284_B7F6_2CF95E38C116__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//{{AFX_ARX_INC_SELECTED
//}}AFX_ARX_INC_SELECTED

//{{AFX_ARX_INC_OTHERS
//}}AFX_ARX_INC_OTHERS
//{{AFX_ARX_FUNC
//}}AFX_ARX_FUNC

#include "ZffDwgScale.h"

// TODO: Here you can add your own includes / declarations
#endif 
