export function isOdd(n) {
    return Math.abs(n % 2) === 1;
}